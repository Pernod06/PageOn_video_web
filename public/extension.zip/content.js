// PageOn Content Script - YouTube Video Detection
// Detects when a YouTube video is being played and shows notification banner
// Also adds analysis buttons to video thumbnails

(function () {
  "use strict";

  const APP_URL = "http://52.72.117.236:3000/";

  let currentVideoId = null;
  let isPlaying = false;
  let videoElement = null;
  let notificationBanner = null;
  let hasShownNotification = false;
  let thumbnailObserver = null;

  // Extract video ID from URL
  function getVideoId() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get("v");
  }

  // Get video information
  function getVideoInfo() {
    const videoId = getVideoId();
    if (!videoId) return null;

    const titleElement = document.querySelector(
      "h1.ytd-video-primary-info-renderer, h1.ytd-watch-metadata yt-formatted-string",
    );
    const channelElement = document.querySelector("#channel-name a, ytd-channel-name a");

    return {
      videoId: videoId,
      url: window.location.href,
      title: titleElement?.textContent?.trim() || "Unknown Title",
      channel: channelElement?.textContent?.trim() || "Unknown Channel",
      isPlaying: isPlaying,
      timestamp: Date.now(),
    };
  }

  // Create notification banner styles - Compact version
  function createStyles() {
    if (document.getElementById("pageon-styles")) return;

    const style = document.createElement("style");
    style.id = "pageon-styles";
    style.textContent = `
      @keyframes pageon-slide-in {
        from { transform: translateY(-20px); opacity: 0; }
        to { transform: translateY(0); opacity: 1; }
      }
      
      @keyframes pageon-slide-out {
        from { transform: translateY(0); opacity: 1; }
        to { transform: translateY(-20px); opacity: 0; }
      }
      
      @keyframes pageon-dot-pulse {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.5; }
      }
      
      .pageon-banner {
        position: fixed;
        top: 12px;
        right: 12px;
        width: 260px;
        background: rgba(15, 23, 42, 0.95);
        backdrop-filter: blur(10px);
        border-radius: 12px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.25);
        border: 1px solid rgba(255, 255, 255, 0.1);
        z-index: 9999;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        animation: pageon-slide-in 0.3s ease-out;
      }
      
      .pageon-banner.hiding {
        animation: pageon-slide-out 0.2s ease-in forwards;
      }
      
      .pageon-banner-content {
        padding: 12px;
      }
      
      .pageon-banner-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 10px;
      }
      
      .pageon-banner-logo {
        display: flex;
        align-items: center;
        gap: 6px;
      }
      
      .pageon-banner-dot {
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background: #22c55e;
        animation: pageon-dot-pulse 1.5s infinite;
      }
      
      .pageon-banner-name {
        font-size: 12px;
        font-weight: 600;
        color: #3b82f6;
      }
      
      .pageon-banner-close {
        background: transparent;
        border: none;
        color: #64748b;
        width: 20px;
        height: 20px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 4px;
        transition: all 0.2s;
      }
      
      .pageon-banner-close:hover {
        color: #f1f5f9;
        background: rgba(255, 255, 255, 0.1);
      }
      
      .pageon-banner-title {
        font-size: 13px;
        font-weight: 500;
        color: #e2e8f0;
        line-height: 1.3;
        margin-bottom: 10px;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
      }
      
      .pageon-banner-btn {
        width: 100%;
        padding: 8px 12px;
        background: #3b82f6;
        border: none;
        border-radius: 8px;
        color: white;
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
      }
      
      .pageon-banner-btn:hover {
        background: #2563eb;
        transform: translateY(-1px);
      }
    `;
    document.head.appendChild(style);
  }

  // Create and show notification banner
  function showNotificationBanner(videoInfo) {
    // Don't show if already shown for this video
    if (hasShownNotification) return;
    hasShownNotification = true;

    // Remove existing banner if any
    hideNotificationBanner();

    // Create styles
    createStyles();

    // Create banner element - Compact version
    notificationBanner = document.createElement("div");
    notificationBanner.className = "pageon-banner";
    notificationBanner.innerHTML = `
      <div class="pageon-banner-content">
        <div class="pageon-banner-header">
          <div class="pageon-banner-logo">
            <div class="pageon-banner-dot"></div>
            <span class="pageon-banner-name">PageOn</span>
          </div>
          <button class="pageon-banner-close" id="pageon-close">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
              <path d="M18 6L6 18M6 6l12 12"/>
            </svg>
          </button>
        </div>
        <div class="pageon-banner-title">${escapeHtml(videoInfo.title)}</div>
        <button class="pageon-banner-btn" id="pageon-analyze">
          <span>🚀 Analyze Video</span>
        </button>
      </div>
    `;

    document.body.appendChild(notificationBanner);

    // Add event listeners
    document.getElementById("pageon-close").addEventListener("click", () => {
      sessionStorage.setItem("pageon-dismissed", "true");
      hideNotificationBanner();
    });
    document.getElementById("pageon-analyze").addEventListener("click", () => {
      const videoUrl = encodeURIComponent(videoInfo.url);
      window.open(`${APP_URL}?video=${videoUrl}`, "_blank");
      hideNotificationBanner();
    });

    // Auto-hide after 8 seconds
    setTimeout(() => {
      if (notificationBanner && notificationBanner.parentNode) {
        hideNotificationBanner();
      }
    }, 8000);
  }

  // Hide notification banner
  function hideNotificationBanner() {
    if (notificationBanner && notificationBanner.parentNode) {
      notificationBanner.classList.add("hiding");
      setTimeout(() => {
        if (notificationBanner && notificationBanner.parentNode) {
          notificationBanner.parentNode.removeChild(notificationBanner);
          notificationBanner = null;
        }
      }, 200);
    }
  }

  // Escape HTML to prevent XSS
  function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
  }

  // Send video status to background script
  function sendVideoStatus(status, videoInfo) {
    chrome.runtime
      .sendMessage({
        type: "YOUTUBE_VIDEO_STATUS",
        status: status,
        data: videoInfo,
      })
      .catch(() => {
        // Extension context may be invalidated, ignore
      });
  }

  // Monitor video element
  function setupVideoMonitor() {
    videoElement = document.querySelector("video.html5-main-video, video");

    if (!videoElement) {
      // Retry after a short delay
      setTimeout(setupVideoMonitor, 1000);
      return;
    }

    // Video play event
    videoElement.addEventListener("play", () => {
      isPlaying = true;
      const info = getVideoInfo();
      if (info) {
        console.log("[PageOn] Video started playing:", info.title);
        sendVideoStatus("playing", info);

        // Show notification if not dismissed
        if (!sessionStorage.getItem("pageon-dismissed")) {
          // Small delay to ensure video info is loaded
          setTimeout(() => {
            const updatedInfo = getVideoInfo();
            if (updatedInfo) {
              showNotificationBanner(updatedInfo);
            }
          }, 1500);
        }
      }
    });

    // Video pause event
    videoElement.addEventListener("pause", () => {
      isPlaying = false;
      const info = getVideoInfo();
      if (info) {
        console.log("[PageOn] Video paused:", info.title);
        sendVideoStatus("paused", info);
      }
    });

    // Video ended event
    videoElement.addEventListener("ended", () => {
      isPlaying = false;
      const info = getVideoInfo();
      if (info) {
        console.log("[PageOn] Video ended:", info.title);
        sendVideoStatus("ended", info);
      }
      hideNotificationBanner();
    });

    // Check if video is already playing
    if (!videoElement.paused) {
      isPlaying = true;
      const info = getVideoInfo();
      if (info) {
        console.log("[PageOn] Video already playing:", info.title);
        sendVideoStatus("playing", info);

        // Show notification if not dismissed
        if (!sessionStorage.getItem("pageon-dismissed")) {
          setTimeout(() => {
            const updatedInfo = getVideoInfo();
            if (updatedInfo) {
              showNotificationBanner(updatedInfo);
            }
          }, 1500);
        }
      }
    }
  }

  // Detect video ID changes (YouTube SPA navigation)
  function setupNavigationMonitor() {
    let lastVideoId = getVideoId();

    // Check for URL changes periodically
    setInterval(() => {
      const newVideoId = getVideoId();
      if (newVideoId && newVideoId !== lastVideoId) {
        lastVideoId = newVideoId;
        currentVideoId = newVideoId;
        hasShownNotification = false; // Reset notification for new video
        console.log("[PageOn] New video detected:", newVideoId);

        // Hide current banner
        hideNotificationBanner();

        // Remove old player button if exists
        const oldButton = document.querySelector('.pageon-player-btn-container');
        if (oldButton) {
          oldButton.remove();
        }

        // Reset and setup monitor for new video
        setTimeout(setupVideoMonitor, 500);

        // Re-inject player button for new video
        setTimeout(() => {
          injectPlayerButton();
        }, 1500);

        const info = getVideoInfo();
        if (info) {
          sendVideoStatus("video_changed", info);
        }
      }
    }, 1000);
  }

  // Listen for messages from background script
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "GET_VIDEO_STATUS") {
      const info = getVideoInfo();
      sendResponse({
        isYouTube: true,
        hasVideo: !!getVideoId(),
        videoInfo: info,
      });
    }
    return true;
  });

  // ========== Thumbnail Overlay Button Feature ==========

  // Create the PageOn button SVG icon
  function createPageOnIcon() {
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <polygon points="5 3 19 12 5 21 5 3"></polygon>
    </svg>`;
  }

  // Extract video URL from thumbnail link
  function extractVideoUrl(thumbnail, debug = false) {
    let linkAnchor = null;
    let foundIn = '';
    
    // Strategy 1: Check if thumbnail itself is an anchor
    if (thumbnail.tagName === 'A') {
      linkAnchor = thumbnail;
      foundIn = 'thumbnail itself';
    }
    
    // Strategy 2: Look for a#thumbnail inside thumbnail
    if (!linkAnchor) {
      linkAnchor = thumbnail.querySelector('a#thumbnail');
      if (linkAnchor) foundIn = 'a#thumbnail inside';
    }
    
    // Strategy 3: Look for any anchor with video URL inside thumbnail
    if (!linkAnchor) {
      linkAnchor = thumbnail.querySelector('a[href*="/watch"], a[href*="/shorts/"]');
      if (linkAnchor) foundIn = 'video link inside thumbnail';
    }
    
    // Strategy 4: Look in parent containers (YouTube首页结构)
    if (!linkAnchor) {
      const parents = [
        'ytd-rich-item-renderer',
        'ytd-rich-grid-media',
        'ytd-video-renderer', 
        'ytd-grid-video-renderer',
        'ytd-compact-video-renderer',
        'ytd-playlist-video-renderer',
        'ytd-reel-item-renderer'
      ];
      
      for (const parentSelector of parents) {
        const parent = thumbnail.closest(parentSelector);
        if (parent) {
          if (debug) console.log('[PageOn] Found parent:', parentSelector);
          
          // First try a#thumbnail
          linkAnchor = parent.querySelector('a#thumbnail');
          if (linkAnchor) {
            foundIn = `a#thumbnail in ${parentSelector}`;
            break;
          }
          
          // Then try any video link
          linkAnchor = parent.querySelector('a[href*="/watch"], a[href*="/shorts/"]');
          if (linkAnchor) {
            foundIn = `video link in ${parentSelector}`;
            break;
          }
        }
      }
    }
    
    // Strategy 5: Look for sibling elements
    if (!linkAnchor && thumbnail.parentElement) {
      linkAnchor = thumbnail.parentElement.querySelector('a[href*="/watch"], a[href*="/shorts/"]');
      if (linkAnchor) foundIn = 'sibling element';
    }
    
    // Strategy 6: Look in the entire document for links near this thumbnail
    if (!linkAnchor) {
      // Try to find the closest video container and look for any link
      const container = thumbnail.closest('[class*="video"], [class*="item"], [class*="renderer"]');
      if (container) {
        linkAnchor = container.querySelector('a[href*="/watch"], a[href*="/shorts/"]');
        if (linkAnchor) foundIn = 'nearby container';
      }
    }
    
    if (!linkAnchor) {
      if (debug) {
        console.log('[PageOn] Debug - No link found. Thumbnail info:');
        console.log('[PageOn] - Tag:', thumbnail.tagName);
        console.log('[PageOn] - Classes:', thumbnail.className);
        console.log('[PageOn] - Parent:', thumbnail.parentElement?.tagName, thumbnail.parentElement?.className);
        console.log('[PageOn] - HTML (first 300):', thumbnail.outerHTML.substring(0, 300));
      }
      return null;
    }
    
    const href = linkAnchor.href || linkAnchor.getAttribute('href');
    if (!href) {
      if (debug) console.log('[PageOn] Link found but no href');
      return null;
    }
    
    // Handle different YouTube URL formats
    if (href.includes('/watch') || href.includes('/shorts/')) {
      if (debug) console.log('[PageOn] ✅ Found video URL in:', foundIn, '-', href);
      // Ensure full URL
      if (href.startsWith('/')) {
        return 'https://www.youtube.com' + href;
      }
      return href;
    }
    
    if (debug) console.log('[PageOn] Link found but not a video URL:', href);
    return null;
  }

  // Check if thumbnail is for a valid video (not a channel, playlist header, etc.)
  function isValidVideoThumbnail(thumbnail) {
    // Skip if already processed
    if (thumbnail.hasAttribute('data-pageon-injected')) {
      return false;
    }
    
    // Skip channel avatars and non-video thumbnails
    const parent = thumbnail.closest('ytd-channel-renderer, ytd-guide-entry-renderer, ytd-playlist-header-renderer');
    if (parent) {
      return false;
    }
    
    // Must have a valid video link
    const videoUrl = extractVideoUrl(thumbnail);
    if (!videoUrl) {
      return false;
    }
    
    return true;
  }

  // Create and inject the analysis button into a thumbnail
  function injectThumbnailButton(thumbnail, debug = false) {
    if (!isValidVideoThumbnail(thumbnail)) {
      return false;
    }

    const videoUrl = extractVideoUrl(thumbnail, debug);
    if (!videoUrl) {
      return false;
    }

    // Mark as processed
    thumbnail.setAttribute('data-pageon-injected', 'true');

    // Ensure thumbnail container has relative positioning
    const computedStyle = window.getComputedStyle(thumbnail);
    if (computedStyle.position === 'static') {
      thumbnail.style.position = 'relative';
    }

    // Check if button already exists
    if (thumbnail.querySelector('.pageon-thumbnail-btn')) {
      return false;
    }

    // Create the button
    const btn = document.createElement('button');
    btn.className = 'pageon-thumbnail-btn';
    btn.setAttribute('aria-label', 'PageOn 视频分析');
    btn.innerHTML = `
      ${createPageOnIcon()}
    `;

    // Handle click
    btn.addEventListener('click', (e) => {
      // CRITICAL: Stop propagation to prevent YouTube from playing the video
      e.stopPropagation();
      e.preventDefault();
      e.stopImmediatePropagation();

      console.log('[PageOn] Thumbnail button clicked:', videoUrl);
      
      // Open analysis page
      const analysisUrl = `${APP_URL}?video=${encodeURIComponent(videoUrl)}`;
      window.open(analysisUrl, '_blank');
    }, true); // Use capture phase

    // Also prevent mousedown from bubbling (YouTube uses this)
    btn.addEventListener('mousedown', (e) => {
      e.stopPropagation();
      e.preventDefault();
    }, true);

    // Insert button into thumbnail
    try {
      thumbnail.appendChild(btn);
      return true;
    } catch (error) {
      console.error('[PageOn] Error injecting button:', error);
      return false;
    }
  }

  // Process all visible thumbnails
  function processAllThumbnails() {
    // Select all thumbnail containers that haven't been processed
    const selectors = [
      'ytd-thumbnail:not([data-pageon-injected])',
      'ytd-playlist-thumbnail:not([data-pageon-injected])'
    ];
    
    const thumbnails = document.querySelectorAll(selectors.join(', '));
    
    console.log(`[PageOn] Found ${thumbnails.length} thumbnails to process`);
    
    // If no thumbnails found with our selectors, try to find video cards directly
    if (thumbnails.length === 0) {
      console.log('[PageOn] Trying alternative approach - looking for video cards...');
      processVideoCards();
      return;
    }
    
    let injectedCount = 0;
    let skippedCount = 0;
    
    thumbnails.forEach((thumbnail, index) => {
      const result = injectThumbnailButton(thumbnail, index < 2); // Debug first 2
      if (result) {
        injectedCount++;
      } else {
        skippedCount++;
      }
    });

    if (injectedCount > 0) {
      console.log(`[PageOn] ✅ Successfully injected buttons into ${injectedCount} thumbnails (skipped: ${skippedCount})`);
    } else if (thumbnails.length > 0) {
      console.log(`[PageOn] ⚠️ Found ${thumbnails.length} thumbnails but none were injected, trying alternative...`);
      processVideoCards();
    }
  }
  
  // Alternative approach: Process video cards directly on YouTube homepage
  function processVideoCards() {
    // YouTube 首页视频卡片选择器
    const cardSelectors = [
      'ytd-rich-item-renderer',
      'ytd-video-renderer',
      'ytd-grid-video-renderer',
      'ytd-compact-video-renderer'
    ];
    
    const cards = document.querySelectorAll(cardSelectors.map(s => `${s}:not([data-pageon-injected])`).join(', '));
    console.log(`[PageOn] Found ${cards.length} video cards to process`);
    
    let injectedCount = 0;
    
    cards.forEach((card, index) => {
      if (card.hasAttribute('data-pageon-injected')) return;
      
      // 找到这个卡片中的视频链接
      const videoLink = card.querySelector('a[href*="/watch"], a[href*="/shorts/"]');
      if (!videoLink) {
        if (index < 2) {
          console.log('[PageOn] Card has no video link:', card.tagName, card.className);
        }
        return;
      }
      
      const href = videoLink.href;
      if (!href || (!href.includes('/watch') && !href.includes('/shorts/'))) {
        return;
      }
      
      // 找到缩略图容器或创建按钮容器
      let thumbnailContainer = card.querySelector('ytd-thumbnail, #thumbnail');
      if (!thumbnailContainer) {
        // 尝试找到图片区域
        thumbnailContainer = card.querySelector('a#thumbnail, .ytd-thumbnail');
      }
      
      if (!thumbnailContainer) {
        // 使用卡片本身作为容器
        thumbnailContainer = card;
      }
      
      // 标记为已处理
      card.setAttribute('data-pageon-injected', 'true');
      
      // 确保容器有相对定位
      const computedStyle = window.getComputedStyle(thumbnailContainer);
      if (computedStyle.position === 'static') {
        thumbnailContainer.style.position = 'relative';
      }
      
      // 检查是否已有按钮
      if (thumbnailContainer.querySelector('.pageon-thumbnail-btn')) {
        return;
      }
      
      // 创建按钮
      const btn = document.createElement('button');
      btn.className = 'pageon-thumbnail-btn';
      btn.setAttribute('aria-label', 'PageOn 视频分析');
      btn.innerHTML = `${createPageOnIcon()}<span class="pageon-btn-text">PageOn</span>`;
      
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        e.preventDefault();
        e.stopImmediatePropagation();
        console.log('[PageOn] Button clicked:', href);
        window.open(`${APP_URL}?video=${encodeURIComponent(href)}`, '_blank');
      }, true);
      
      btn.addEventListener('mousedown', (e) => {
        e.stopPropagation();
        e.preventDefault();
      }, true);
      
      thumbnailContainer.appendChild(btn);
      injectedCount++;
      
      if (index < 2) {
        console.log('[PageOn] ✅ Injected button into card:', href.substring(0, 60));
      }
    });
    
    if (injectedCount > 0) {
      console.log(`[PageOn] ✅ Successfully injected ${injectedCount} buttons via card approach`);
    }
  }

  // Debounce function for performance optimization
  function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }

  // Setup MutationObserver to handle dynamically loaded thumbnails
  function setupThumbnailObserver() {
    console.log('[PageOn] setupThumbnailObserver() called');
    
    if (thumbnailObserver) {
      thumbnailObserver.disconnect();
      console.log('[PageOn] Disconnected existing observer');
    }

    // Debounced version of processAllThumbnails for performance
    const debouncedProcess = debounce(processAllThumbnails, 150);

    // Always process on any DOM mutation (more aggressive approach)
    thumbnailObserver = new MutationObserver((mutations) => {
      debouncedProcess();
    });

    // Observe the entire body for changes (YouTube is a SPA)
    if (document.body) {
      thumbnailObserver.observe(document.body, {
        childList: true,
        subtree: true
      });
      console.log('[PageOn] ✅ Thumbnail observer attached to body');
    } else {
      console.log('[PageOn] ⚠️ document.body not available, waiting...');
      // Wait for body to be available
      const bodyWaiter = setInterval(() => {
        if (document.body) {
          clearInterval(bodyWaiter);
          thumbnailObserver.observe(document.body, {
            childList: true,
            subtree: true
          });
          console.log('[PageOn] ✅ Thumbnail observer attached to body (delayed)');
          processAllThumbnails();
        }
      }, 100);
    }

    console.log('[PageOn] Thumbnail observer setup complete');

    // Process existing thumbnails immediately (multiple attempts for lazy loading)
    processAllThumbnails();
    
    setTimeout(() => {
      console.log('[PageOn] Delayed attempt 1 (500ms)...');
      processAllThumbnails();
    }, 500);
    
    setTimeout(() => {
      console.log('[PageOn] Delayed attempt 2 (1500ms)...');
      processAllThumbnails();
    }, 1500);
    
    setTimeout(() => {
      console.log('[PageOn] Delayed attempt 3 (3000ms)...');
      processAllThumbnails();
    }, 3000);
    
    setTimeout(() => {
      console.log('[PageOn] Delayed attempt 4 (5000ms)...');
      processAllThumbnails();
    }, 5000);
    
    // Also process on scroll (for infinite scroll pages)
    let scrollTimeout;
    window.addEventListener('scroll', () => {
      clearTimeout(scrollTimeout);
      scrollTimeout = setTimeout(() => {
        processAllThumbnails();
      }, 500);
    }, { passive: true });
  }

  // ========== End Thumbnail Overlay Feature ==========

  // Initialize
  function init() {
    console.log("[PageOn] ========== Content script initializing ==========");
    console.log("[PageOn] Current URL:", window.location.href);
    console.log("[PageOn] Document ready state:", document.readyState);
    
    currentVideoId = getVideoId();

    if (currentVideoId) {
      console.log("[PageOn] YouTube video page detected, Video ID:", currentVideoId);
      setupVideoMonitor();
    } else {
      console.log("[PageOn] Not a video page (homepage or other)");
    }

    setupNavigationMonitor();
    
    // Initialize thumbnail overlay buttons (works on homepage and all pages)
    try {
      console.log("[PageOn] Setting up thumbnail observer...");
      setupThumbnailObserver();
    } catch (error) {
      console.error("[PageOn] Error setting up thumbnail observer:", error);
    }

    // Notify background that content script is ready
    sendVideoStatus("content_script_ready", { url: window.location.href });
    
    console.log("[PageOn] ========== Content script initialized ==========");
  }

  // Wait for page to be ready
  console.log("[PageOn] Content script loaded, waiting for page ready...");
  console.log("[PageOn] Document ready state:", document.readyState);
  
  if (document.readyState === "complete") {
    console.log("[PageOn] Page already complete, initializing now...");
    init();
  } else {
    console.log("[PageOn] Page not ready, waiting for load event...");
    window.addEventListener("load", () => {
      console.log("[PageOn] Load event fired, initializing...");
      init();
    });
    // Also try on DOMContentLoaded
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", () => {
        console.log("[PageOn] DOMContentLoaded event fired");
      });
    }
  }
})();
